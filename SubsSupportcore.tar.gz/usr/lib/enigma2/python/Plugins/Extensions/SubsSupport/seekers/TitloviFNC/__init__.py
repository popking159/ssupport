# Dummy file to make this directory a package.
from . import service as titloviFNC
