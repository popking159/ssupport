#!/usr/bin/env python
import sys
sys.path.append('/usr/lib/enigma2/python/')
sys.path.append('/usr/lib/python3.11/')

from Components.Sources.ServiceEvent import ServiceEvent
from Screens.InfoBar import InfoBar
from enigma import eServiceCenter, iServiceInformation, eServiceReference, eDVBServicePMTHandler
from Screens.ChannelSelection import service_types_tv
from ServiceReference import ServiceReference

try:
    session = InfoBar.instance.session
    service = session.nav.getCurrentService()
    info = service and service.info()
    
    print("=== CURRENT SERVICE SUBTITLE INFO ===")
    print("Service ref:", session.nav.getCurrentlyPlayingServiceReference().toString())
    
    if info:
        print("Subtitles available (sUser+10):", info.getInfo(iServiceInformation.sUser + 10))
        print("Video PID:", info.getInfo(iServiceInformation.sVideoPID))
        print("Audio PID:", info.getInfo(iServiceInformation.sAudioPID))
        
    subtitle = service.subtitle()
    if subtitle:
        tracks = subtitle.getNumberOfTracks()
        print("Subtitle tracks count:", tracks)
        for i in range(tracks):
            track = subtitle.getTrackInfo(i)
            print(f"  Track {i}: PID={track.getPID()}, Type={track.getType()}, Lang={track.getLanguage()}")
    else:
        print("No subtitle service available")
        
except Exception as e:
    print("Error:", str(e))
